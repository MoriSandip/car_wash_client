import { useState } from "react";
import {
  useGetDailyAttendanceReportQuery,
  useGetWorkersQuery,
} from "@/redux/features/worker/workerApi";

const today = () => {
  const now = new Date();
  const localDate = new Date(now.getTime() - now.getTimezoneOffset() * 60_000);
  return localDate.toISOString().slice(0, 10);
};

const time = (value?: string | null) =>
  value
    ? new Date(value).toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
      })
    : "—";

const AttendanceReport = () => {
  const [date, setDate] = useState(today);
  const [workerId, setWorkerId] = useState("");
  const workersQuery = useGetWorkersQuery({ limit: 1000, status: "ACTIVE" });
  const { data, isLoading, isError, refetch, isFetching } =
    useGetDailyAttendanceReportQuery({ date, workerId: workerId || undefined });

  return (
    <main className="mx-auto w-full max-w-7xl space-y-6 p-16">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Worker Attendance</h1>
        <p className="mt-1 text-sm text-slate-500">
          Daily worker-wise punch-in and punch-out report with selfie verification.
        </p>
      </header>

      <section className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-end">
        <label className="grid gap-1 text-sm font-medium text-slate-700">
          Attendance date
          <input
            type="date"
            value={date}
            onChange={(event) => setDate(event.target.value)}
            className="h-10 rounded-md border border-slate-300 px-3"
          />
        </label>
        <label className="grid gap-1 text-sm font-medium text-slate-700">
          Worker
          <select
            value={workerId}
            onChange={(event) => setWorkerId(event.target.value)}
            className="h-10 min-w-48 rounded-md border border-slate-300 px-3"
          >
            <option value="">All active workers</option>
            {(workersQuery.data?.data ?? []).map((worker) => (
              <option key={worker._id} value={worker._id}>
                {worker.name}
              </option>
            ))}
          </select>
        </label>
        <button
          type="button"
          onClick={() => refetch()}
          disabled={isFetching}
          className="h-10 rounded-md bg-sky-700 px-4 text-sm font-semibold text-white hover:bg-sky-800 disabled:opacity-50"
        >
          {isFetching ? "Refreshing…" : "Refresh"}
        </button>
      </section>

      {workersQuery.isError ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">
          Could not load worker filters.
        </p>
      ) : null}
      {isError ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">
          Could not load the attendance report.
        </p>
      ) : null}

      {data ? (
        <>
          <section className="grid gap-3 sm:grid-cols-3">
            {[
              ["Workers", data.summary.totalWorkers],
              ["Present", data.summary.present],
              ["Absent", data.summary.absent],
            ].map(([label, count]) => (
              <div key={label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                <p className="text-sm text-slate-500">{label}</p>
                <p className="mt-1 text-2xl font-bold text-slate-900">{count}</p>
              </div>
            ))}
          </section>

          <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 px-5 py-4">
              <h2 className="font-semibold text-slate-900">
                Daily report · {new Date(`${data.date}T00:00:00`).toLocaleDateString("en-IN")}
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px] text-left text-sm">
                <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                  <tr>
                    <th className="px-4 py-3">Worker</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Punch in</th>
                    <th className="px-4 py-3">In selfie</th>
                    <th className="px-4 py-3">Punch out</th>
                    <th className="px-4 py-3">Out selfie</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {isLoading ? (
                    <tr><td className="px-4 py-8 text-slate-500" colSpan={6}>Loading report…</td></tr>
                  ) : data.records.length ? (
                    data.records.map(({ worker, attendance, status }) => (
                      <tr key={worker._id}>
                        <td className="px-4 py-3">
                          <p className="font-medium text-slate-900">{worker.name}</p>
                          <p className="text-xs text-slate-500">{worker.phone || worker.email}</p>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                            status === "PRESENT" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
                          }`}>{status}</span>
                        </td>
                        <td className="px-4 py-3">{time(attendance?.punchInAt)}</td>
                        <td className="px-4 py-3">
                          {attendance?.punchInSelfie ? (
                            <a href={attendance.punchInSelfie} target="_blank" rel="noreferrer">
                              <img src={attendance.punchInSelfie} alt={`${worker.name} punch-in selfie`} className="h-12 w-12 rounded-md object-cover" />
                            </a>
                          ) : "—"}
                        </td>
                        <td className="px-4 py-3">{time(attendance?.punchOutAt)}</td>
                        <td className="px-4 py-3">
                          {attendance?.punchOutSelfie ? (
                            <a href={attendance.punchOutSelfie} target="_blank" rel="noreferrer">
                              <img src={attendance.punchOutSelfie} alt={`${worker.name} punch-out selfie`} className="h-12 w-12 rounded-md object-cover" />
                            </a>
                          ) : "—"}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr><td className="px-4 py-8 text-slate-500" colSpan={6}>No active workers found.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </>
      ) : null}
    </main>
  );
};

export default AttendanceReport;
