import { baseApi } from "@/redux/api/baseApi";

export type TMembershipStatus =
  | "Pending"
  | "Active"
  | "Expired"
  | "Cancelled";

export type TPaymentStatus =
  | "Pending"
  | "Paid"
  | "Failed"
  | "Refunded";

export interface TMembership {
  _id: string;
  societyId: any;
  flatId: any;
  carId: any;
  planId: any;
  offerId?: any;
  startDate: string;
  endDate: string;
  totalAmount: number;
  paymentStatus: TPaymentStatus;
  status: TMembershipStatus;
  remarks?: string;
  isDeleted?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export type TMembershipPayload = {
  societyId: string;
  flatId: string;
  carId: string;
  planId: string;
  offerId?: string | null;
  startDate: string;
  endDate: string;
  paymentStatus: TPaymentStatus;
  status: TMembershipStatus;
  remarks?: string;
};

export interface TMembershipListParams {
  search?: string;
  status?: TMembershipStatus | "";
  paymentStatus?: TPaymentStatus | "";
  societyId?: string;
  flatId?: string;
  carId?: string;
  planId?: string;
  page?: number;
  limit?: number;
}

export interface TMembershipListResponse {
  data: TMembership[];
  meta?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface TMembershipStats {
  total: number;
  active: number;
  pending: number;
  expired: number;
  cancelled: number;
}

const unwrap = (response: any) => response?.data ?? response;

const getArray = (response: any): any[] => {
  const candidates = [
    response?.data,
    response?.data?.data,
    response?.data?.result,
    response?.data?.results,
    response?.data?.docs,
    response?.data?.items,
    response?.result,
    response?.results,
    response?.docs,
    response?.items,
    response,
  ];

  return candidates.find(Array.isArray) ?? [];
};

export const membershipApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getMemberships: builder.query<
      TMembershipListResponse,
      TMembershipListParams | void
    >({
      query: (params) => ({
        url: "/memberships",
        method: "GET",
        params: params || {},
      }),
      transformResponse: (response: any): TMembershipListResponse => {
        const result = getArray(response);

        return {
          data: result,
          meta:
            response?.meta ??
            response?.data?.meta ??
            response?.data?.data?.meta,
        };
      },
      providesTags: (result) =>
        result
          ? [
              ...result.data.map(({ _id }) => ({
                type: "membership" as const,
                id: _id,
              })),
              { type: "membership" as const, id: "LIST" },
            ]
          : [{ type: "membership" as const, id: "LIST" }],
    }),

    getSingleMembership: builder.query<TMembership, string>({
      query: (id) => `/memberships/${id}`,
      transformResponse: unwrap,
      providesTags: (_result, _error, id) => [
        { type: "membership", id },
      ],
    }),

    getMembershipStats: builder.query<TMembershipStats, void>({
      query: () => "/memberships/stats",
      transformResponse: unwrap,
      providesTags: [{ type: "membership", id: "STATS" }],
    }),

    createMembership: builder.mutation<
      TMembership,
      TMembershipPayload
    >({
      query: (body) => ({
        url: "/memberships",
        method: "POST",
        body,
      }),
      transformResponse: unwrap,
      invalidatesTags: [
        { type: "membership", id: "LIST" },
        { type: "membership", id: "STATS" },
      ],
    }),

    updateMembership: builder.mutation<
      TMembership,
      { id: string; data: Partial<TMembershipPayload> }
    >({
      query: ({ id, data }) => ({
        url: `/memberships/${id}`,
        method: "PUT",
        body: data,
      }),
      transformResponse: unwrap,
      invalidatesTags: (_result, _error, { id }) => [
        { type: "membership", id },
        { type: "membership", id: "LIST" },
        { type: "membership", id: "STATS" },
      ],
    }),

    deleteMembership: builder.mutation<
      { success: boolean },
      string
    >({
      query: (id) => ({
        url: `/memberships/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: [
        { type: "membership", id: "LIST" },
        { type: "membership", id: "STATS" },
      ],
    }),
  }),
});

export const {
  useGetMembershipsQuery,
  useGetSingleMembershipQuery,
  useGetMembershipStatsQuery,
  useCreateMembershipMutation,
  useUpdateMembershipMutation,
  useDeleteMembershipMutation,
} = membershipApi;