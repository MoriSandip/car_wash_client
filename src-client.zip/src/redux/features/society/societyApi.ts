
import { baseApi } from "../../api/baseApi";

export type TSocietyStatus = "PENDING" | "VERIFIED" | "REJECTED";

export type TSociety = {
  _id: string;
  name: string;
  address: string;
  city: string;
  state?: string;
  pincode?: string;
  contactPerson?: string;
  phone?: string;
  email?: string;
  description?: string;
  status?: TSocietyStatus;
  verificationNote?: string;
  verifiedAt?: string | null;
  isDeleted?: boolean;
  createdAt?: string;
};

export type TSocietyPayload = {
  name: string;
  address: string;
  city: string;
  state?: string;
  pincode?: string;
  contactPerson?: string;
  phone?: string;
  email?: string;
  description?: string;
};

const SocietyApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    // Admin: get all societies
    getSocieties: builder.query<any, void>({
      query: () => ({
        url: "/societies",
        method: "GET",
      }),
      providesTags: ["society"],
    }),

    // Customer: get only societies created by logged-in customer
 

    // Get one society
    getSingleSociety: builder.query<any, string>({
      query: (id) => ({
        url: `/societies/${id}`,
        method: "GET",
      }),
      providesTags: ["society"],
    }),

    // Create society
    createSociety: builder.mutation<any, TSocietyPayload>({
      query: (payload) => ({
        url: "/societies",
        method: "POST",
        body: payload,
      }),
      invalidatesTags: ["society"],
    }),

    // Update society
    updateSociety: builder.mutation<
      any,
      { id: string; data: Partial<TSocietyPayload> }
    >({
      query: ({ id, data }) => ({
        url: `/societies/${id}`,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["society"],
    }),

    // Delete society
    deleteSociety: builder.mutation<any, string>({
      query: (id) => ({
        url: `/societies/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["society"],
    }),

    // Admin: verify society
    verifySociety: builder.mutation<any, string>({
      query: (id) => ({
        url: `/societies/${id}/verify`,
        method: "PATCH",
      }),
      invalidatesTags: ["society"],
    }),

    getMySocieties: builder.query({
  query: () => ({
    url: "/societies/my",
    method: "GET",
  }),
  providesTags: ["Society"],
}),
    // Admin: reject society
    rejectSociety: builder.mutation<
      any,
      { id: string; verificationNote: string }
    >({
      query: ({ id, verificationNote }) => ({
        url: `/societies/${id}/reject`,
        method: "PATCH",
        body: { verificationNote },
      }),
      invalidatesTags: ["society"],
    }),
  }),
});

export const {
  useGetSocietiesQuery,
  useGetMySocietiesQuery,
  useGetSingleSocietyQuery,
  useCreateSocietyMutation,
  useUpdateSocietyMutation,
  useDeleteSocietyMutation,
  useVerifySocietyMutation,
  useRejectSocietyMutation, 
} = SocietyApi;
