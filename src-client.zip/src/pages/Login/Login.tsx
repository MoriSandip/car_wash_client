import CarInput from "@/components/form/CarInput";
import CarForm from "@/components/form/CarForm";
import { Button } from "@/components/ui/button";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { FieldValues, SubmitHandler } from "react-hook-form";
import {
  useLoginMutation,
  useWorkerLoginMutation,
  useCustomerLoginMutation,
} from "@/redux/features/auth/authApi";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAppDispatch } from "@/redux/hooks";
import { verifyToken } from "@/utils/VeryfiedToken";
import { setUser, TUser } from "@/redux/features/auth/authSlice";
import { toast } from "sonner";
import {
  ShieldCheck,
  UserRound,
  BriefcaseBusiness,
  ArrowRight,
} from "lucide-react";
import { useState } from "react";

type TLoginRole = "admin" | "customer" | "worker";

const LoginForm = ({
  onSubmit,
}: {
  onSubmit: SubmitHandler<FieldValues>;
}) => (
  <CarForm
    onSubmit={onSubmit}
    defaultValues={{
      email: "",
      password: "",
    }}
  >
    <div className="space-y-4">
      <CarInput
        type="email"
        name="email"
        label="Email address"
        placeholder="Enter your email"
      />

      <CarInput
        type="password"
        name="password"
        label="Password"
        placeholder="Enter your password"
        className="text-black"
      />
    </div>

    <Button
      type="submit"
      className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-black font-semibold text-white transition"
    >
      Sign in
      <ArrowRight size={17} />
    </Button>
  </CarForm>
);

const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useAppDispatch();

  const [login] = useLoginMutation();
  const [workerLogin] = useWorkerLoginMutation();
  const [customerLogin] = useCustomerLoginMutation();
  const [activeRole, setActiveRole] = useState<TLoginRole>(
    location.pathname === "/customer/login" ? "customer" : "admin",
  );

  const onSubmit: SubmitHandler<FieldValues> = async (data) => {
    const credentials = {
      email: String(data.email ?? "").trim(),
      password: String(data.password ?? ""),
    };

    try {
      let token: string;

      if (activeRole === "worker") {
        const response = await workerLogin(credentials).unwrap();
        token = response.data.accessToken;
      } else if (activeRole === "customer") {
        const response = await customerLogin(credentials).unwrap();
        token = response.data.accessToken;
      } else {
        const response = await login(credentials).unwrap();
        token = response.data.accessToken;
      }

      const user = verifyToken(token) as TUser;
      const expectedRole =
        activeRole === "admin"
          ? "admin"
          : activeRole === "worker"
            ? "WORKER"
            : "CUSTOMER";

      if (user.role !== expectedRole) {
        throw new Error(`Invalid ${activeRole} token payload`);
      }

      dispatch(setUser({ user, token }));
      toast.success(`${activeRole[0].toUpperCase()}${activeRole.slice(1)} logged in`);

      const destination =
        location.state?.from ||
        (activeRole === "admin"
          ? "/dashboard"
          : activeRole === "worker"
            ? "/worker"
            : "/customer");

      navigate(destination, { replace: true });
    } catch (error) {
      console.error(`${activeRole} login error:`, error);
      toast.error(
        `${activeRole[0].toUpperCase()}${activeRole.slice(1)} login failed. Check your email and password.`
      );
    }
  };

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden">
      {/* Monochrome background decoration */}
      <div className="pointer-events-none absolute -left-32 -top-32 h-80 w-80 rounded-full border border-black/10" />
      <div className="pointer-events-none absolute -left-20 -top-20 h-56 w-56 rounded-full border border-black/10" />
      <div className="pointer-events-none absolute -bottom-40 -right-32 h-96 w-96 rounded-full border border-black/10" />

      <div className="relative z-10 grid w-full max-w-5xl overflow-hidden rounded-3xl border border-black/10 bg-white md:grid-cols-2">
        {/* Left panel */}
        <section className="relative hidden min-h-[620px] flex-col justify-between overflow-hidden bg-white p-10 text-black md:flex lg:p-12">
          <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full border border-white/15" />
          <div className="absolute -right-10 -top-10 h-44 w-44 rounded-full border border-white/15" />
          <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-white/[0.04]" />

          <div className="relative z-10">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/30">
              <ShieldCheck size={26} strokeWidth={1.7} />
            </div>

            <p className="mt-8 text-xs font-semibold uppercase tracking-[0.3em] text-black/60">
              Car Wash Booking System
            </p>

            <h1 className="mt-5 text-4xl font-bold leading-tight lg:text-5xl">
              Welcome
              <br />
              back.
            </h1>

            <p className="mt-5 max-w-xs text-sm leading-7 text-black/65">
              Sign in to manage your bookings, services, and account from one
              convenient place.
            </p>
          </div>

       
        </section>

        {/* Right panel */}
        <section className="flex min-w-0 flex-col justify-center p-6 sm:p-10 lg:p-12">
          <div className="mb-8 md:hidden">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-black text-black">
              <ShieldCheck size={24} />
            </div>
            <p className="mt-4 text-xs font-semibold uppercase tracking-[0.2em] text-black/50">
              Car Wash Booking System
            </p>
          </div>

          <div className="mb-8">
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-black/50">
              Your account
            </p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">
              Sign in
            </h2>
            <p className="mt-3 text-sm leading-6 text-black/55">
              Choose your account type, then enter your email and password.
            </p>
          </div>

          <div className="w-full">
            <Tabs
              value={activeRole}
              onValueChange={(value) => {
                if (value === "admin" || value === "customer" || value === "worker") {
                  setActiveRole(value);
                }
              }}
            >
              <TabsList className="mb-6 grid h-12 w-full grid-cols-3 rounded-xl bg-black/5 p-1">
                <TabsTrigger
                  value="admin"
                  className="gap-2 rounded-lg data-[state=active]:bg-black data-[state=active]:text-white"
                >
                  <ShieldCheck size={16} />
                  Admin
                </TabsTrigger>
                <TabsTrigger
                  value="customer"
                  className="gap-2 rounded-lg data-[state=active]:bg-black data-[state=active]:text-white"
                >
                  <UserRound size={16} />
                  Customer
                </TabsTrigger>
                <TabsTrigger
                  value="worker"
                  className="gap-2 rounded-lg data-[state=active]:bg-black data-[state=active]:text-white"
                >
                  <BriefcaseBusiness size={16} />
                  Worker
                </TabsTrigger>
              </TabsList>
              <TabsContent value="admin" className="mt-0">
                <LoginForm onSubmit={onSubmit} />
              </TabsContent>
              <TabsContent value="customer" className="mt-0">
                <LoginForm onSubmit={onSubmit} />
              </TabsContent>
              <TabsContent value="worker" className="mt-0">
                <LoginForm onSubmit={onSubmit} />
              </TabsContent>
            </Tabs>
            <div className="mt-4 text-right">
              <Link
                to={`/forgot-password?role=${activeRole.toUpperCase()}`}
                className="text-sm font-semibold text-black underline underline-offset-4"
              >
                Forgot password?
              </Link>
            </div>
          </div>

          {activeRole === "customer" && (
            <p className="mt-6 text-center text-sm text-black/60">
              New customer?{" "}
              <Link
                to="/customer/register"
                className="font-semibold text-black underline underline-offset-4"
              >
                Create an account
              </Link>
            </p>
          )}
        </section>
      </div>
    </main>
  );
};

export default Login;
