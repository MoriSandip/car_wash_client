import { baseApi } from "@/redux/api/baseApi";

 
export type BookingStatus =
  | "Pending"
  | "Confirmed"
  | "InProgress"
  | "Completed"
  | "Cancelled";

export type BookingReference =
  | string
  | {
      _id?: string;
      id?: string;
      name?: string;
      city?: string;
      flatNumber?: string;
      block?: string;
      registrationNumber?: string;
      make?: string;
      model?: string;
    };

export type BookingNew = {
  _id: string;
  societyId: BookingReference;
  flatId: BookingReference;
  carId: BookingReference;
  serviceId: BookingReference;
  membershipId?: BookingReference;
  bookingDate: string;
  bookingTime: string;
  paymentType: "Membership" | "Individual";
  serviceNameSnapshot: string;
  servicePriceSnapshot: number;
  amountPayable: number;
  paymentStatus: "Pending" | "Paid" | "Failed" | "Refunded";
  status: BookingStatus;
  remarks?: string;
};

export type BookingPayload = {
  societyId: string;
  flatId: string;
  carId: string;
  serviceId: string;
  slotId?: string;
  membershipId?: string;
  bookingDate: string;
  bookingTime: string;
  paymentType: "Membership" | "Individual";
  remarks?: string;
};

export type BookingStats = {
  total?: number;
  pending?: number;
  confirmed?: number;
  inProgress?: number;
  completed?: number;
  cancelled?: number;
  individualPaidRevenue?: number;
  dailyBookings?: {
    date: string;
    bookings: number;
  }[];
};

type ListResponse = {
  data: BookingNew[];
  meta?: {
    page: number;
    limit: number;
    total: number;
    totalPage: number;
  };
};

type BookingListApiResponse = {
  data: ListResponse;
  meta?: ListResponse["meta"];
};

export const bookingNewApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getBookings: builder.query<
      BookingListApiResponse,
      {
        searchTerm?: string;
        page?: number;
        limit?: number;
        status?: string;
        paymentType?: string;
        societyId?: string;
        from?: string;
        to?: string;
      } | void
    >({
      query: (params) => ({
        url: "/bookings",
        method: "GET",
        params: params || {},
      }),
      providesTags: ["BookingNew"],
    }),

    getBookingStats: builder.query<
      { data: BookingStats },
      void
    >({
      query: () => ({
        url: "/bookings/stats",
        method: "GET",
      }),
      providesTags: ["BookingNew"],
    }),

    createBooking: builder.mutation<
      { data: BookingNew },
      BookingPayload
    >({
      query: (body) => ({
        url: "/bookings",
        method: "POST",
        body,
      }),
      invalidatesTags: ["BookingNew", "Slot"],
    }),

    updateBooking: builder.mutation<
      { data: BookingNew },
      {
        id: string;
        body: Partial<
          Pick<BookingNew, "bookingDate" | "bookingTime" | "remarks">
        >;
      }
    >({
      query: ({ id, body }) => ({
        url: `/bookings/${id}`,
        method: "PATCH",
        body,
      }),
      invalidatesTags: ["BookingNew"],
    }),

    changeBookingStatus: builder.mutation<
      { data: BookingNew },
      {
        id: string;
        body: {
          status: BookingStatus;
          paymentStatus?: BookingNew["paymentStatus"];
          remarks?: string;
        };
      }
    >({
      query: ({ id, body }) => ({
        url: `/bookings/${id}/status`,
        method: "PATCH",
        body,
      }),
      invalidatesTags: ["BookingNew"],
    }),

    deleteBooking: builder.mutation<{ data: BookingNew }, string>({
      query: (id) => ({
        url: `/bookings/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["BookingNew"],
    }),
  }),
  overrideExisting: false,
});

export const {
  useGetBookingsQuery,
  useGetBookingStatsQuery,
  useCreateBookingMutation,
  useUpdateBookingMutation,
  useChangeBookingStatusMutation,
  useDeleteBookingMutation,
} = bookingNewApi;
