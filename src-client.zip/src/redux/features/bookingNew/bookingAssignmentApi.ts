import { baseApi } from "@/redux/api/baseApi";

export type TAssignmentWorker = {
  _id: string;
  name?: string;
  email?: string;
  phone?: string;
  mobileNumber?: string;
  status?: string;
};

export type TAssignmentBooking = {
  _id: string;
  bookingDate: string;
  bookingTime: string;
  serviceNameSnapshot: string;
  servicePriceSnapshot: number;
  amountPayable: number;
  paymentType: string;
  paymentStatus: string;
  status: string;
  workerId?: TAssignmentWorker | string | null;
  carId?: any;
  flatId?: any;
  societyId?: any;
};

const getArray = (response: any): any[] => {
  if (Array.isArray(response)) return response;
  if (Array.isArray(response?.data)) return response.data;
  if (Array.isArray(response?.data?.data)) return response.data.data;
  if (Array.isArray(response?.data?.result)) return response.data.result;
  if (Array.isArray(response?.result)) return response.result;
  if (Array.isArray(response?.results)) return response.results;
  return [];
};

export const bookingAssignmentApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getBookingsForAssignment: builder.query<
      { data: TAssignmentBooking[]; meta?: any },
      { page?: number; limit?: number; searchTerm?: string }
    >({
      query: (params) => ({
        url: "/bookings",
        method: "GET",
        params,
      }),
      transformResponse: (response: any) => ({
        data: getArray(response),
        meta: response?.meta ?? response?.data?.meta,
      }),
      providesTags: ["Booking"],
    }),

    getWorkersForAssignment: builder.query<TAssignmentWorker[], void>({
      query: () => ({
        url: "/workers",
        method: "GET",
        params: { page: 1, limit: 100 },
      }),
      transformResponse: (response: any) => getArray(response),
      providesTags: ["Worker"],
    }),

    assignWorkerToBooking: builder.mutation<
      any,
      { bookingId: string; workerId: string }
    >({
      query: ({ bookingId, workerId }) => ({
        url: `/bookings/${bookingId}/assign-worker`,
        method: "PATCH",
        body: { workerId },
      }),
      invalidatesTags: ["Booking"],
    }),

    unassignWorkerFromBooking: builder.mutation<any, string>({
      query: (bookingId) => ({
        url: `/bookings/${bookingId}/unassign-worker`,
        method: "PATCH",
      }),
      invalidatesTags: ["Booking"],
    }),
  }),
});

export const {
  useGetBookingsForAssignmentQuery,
  useGetWorkersForAssignmentQuery,
  useAssignWorkerToBookingMutation,
  useUnassignWorkerFromBookingMutation,
} = bookingAssignmentApi;
