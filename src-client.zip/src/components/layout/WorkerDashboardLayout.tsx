import WorkerSidebar from "../Sidebar/WorkerSidebar";
import { TooltipProvider } from "../ui/tooltip";
 
export function WorkerDashboardLayout() {
  return (
    <TooltipProvider>
      <div className="min-h-screen w-full bg-muted/40">
        <WorkerSidebar />
      </div>
    </TooltipProvider>
  );
}
