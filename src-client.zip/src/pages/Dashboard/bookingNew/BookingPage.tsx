import React, { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Download,
  CalendarCheck,
  Clock,
  CheckCircle2,
  Eye,
  Plus,
  Search,
  Trash2,
  RefreshCw,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import { useGetCarsQuery } from "@/redux/features/car/carApi";
import { useGetFlatsQuery } from "@/redux/features/flat/flatApi";
import { useGetWashServicesQuery } from "@/redux/features/washService/washServiceApi";
import { useGetSocietiesQuery } from "@/redux/features/society/societyApi";
import { useGetMembershipsQuery } from "@/redux/features/membership/membershipApi";

import {
  type BookingStatus,
  useChangeBookingStatusMutation,
  useCreateBookingMutation,
  useDeleteBookingMutation,
  useGetBookingsQuery,
} from "@/redux/features/bookingNew/bookingNewApi";

type AnyRecord = Record<string, any>;
type PaymentType = "Membership" | "Individual";
type DialogMode = "add" | "view";

type BookingForm = {
  societyId: string;
  flatId: string;
  carId: string;
  serviceId: string;
  membershipId: string;
  bookingDate: string;
  bookingTime: string;
  paymentType: PaymentType;
  remarks: string;
};

const initialForm: BookingForm = {
  societyId: "",
  flatId: "",
  carId: "",
  serviceId: "",
  membershipId: "",
  bookingDate: "",
  bookingTime: "10:00",
  paymentType: "Individual",
  remarks: "",
};

const bookingStatuses: BookingStatus[] = [
  "Pending",
  "Confirmed",
  "InProgress",
  "Completed",
  "Cancelled",
];

const getArray = (response: unknown): AnyRecord[] => {
  if (Array.isArray(response)) return response;
  if (!response || typeof response !== "object") return [];

  const obj = response as AnyRecord;

  const candidates = [
    obj.data,
    obj.data?.data,
    obj.data?.result,
    obj.data?.results,
    obj.data?.items,
    obj.data?.docs,
    obj.data?.memberships,
    obj.data?.bookings,
    obj.result,
    obj.results,
    obj.items,
    obj.docs,
    obj.memberships,
    obj.bookings,
  ];

  return candidates.find(Array.isArray) ?? [];
};

const idOf = (value: unknown): string => {
  if (typeof value === "string" || typeof value === "number") {
    return String(value);
  }

  if (!value || typeof value !== "object") return "";

  const obj = value as AnyRecord;
  const id = obj._id ?? obj.id;

  return id == null ? "" : String(id);
};

const relationId = (item: AnyRecord, keys: string[]): string => {
  for (const key of keys) {
    const value = item?.[key];

    if (value !== undefined && value !== null && value !== "") {
      return idOf(value);
    }
  }

  return "";
};

const labelOf = (item: AnyRecord, keys: string[]): string => {
  for (const key of keys) {
    const value = item?.[key];

    if (value !== undefined && value !== null && String(value).trim()) {
      return String(value);
    }
  }

  return idOf(item) || "Unnamed";
};

const errorMessage = (error: any, fallback: string): string =>
  error?.data?.message ??
  error?.data?.error ??
  error?.message ??
  fallback;

const formatDate = (value: unknown): string => {
  if (!value) return "—";

  const date = new Date(String(value));

  return Number.isNaN(date.getTime())
    ? String(value)
    : date.toLocaleDateString();
};

const statusClass = (status: string) => {
  switch (status) {
    case "Completed":
      return "bg-green-100 text-green-700";
    case "Cancelled":
      return "bg-red-100 text-red-700";
    case "InProgress":
      return "bg-blue-100 text-blue-700";
    case "Confirmed":
      return "bg-purple-100 text-purple-700";
    default:
      return "bg-amber-100 text-amber-700";
  }
};

const BookingPage: React.FC = () => {
  const [form, setForm] = useState<BookingForm>({ ...initialForm });
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [page, setPage] = useState(1);

  const [formOpen, setFormOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<DialogMode>("add");
  const [selectedBooking, setSelectedBooking] =
    useState<AnyRecord | null>(null);
  const [actionError, setActionError] = useState("");

  const {
    data: bookingResponse,
    isLoading,
    isFetching,
    isError,
    refetch,
  } = useGetBookingsQuery({
    searchTerm,
    status: statusFilter === "All" ? undefined : statusFilter,
    page,
    limit: 10,
  });

  const { data: societyResponse, isLoading: societiesLoading } =
    useGetSocietiesQuery();

  const { data: flatResponse, isLoading: flatsLoading } =
    useGetFlatsQuery();

  const { data: carResponse, isLoading: carsLoading } =
    useGetCarsQuery({});

  const { data: serviceResponse, isLoading: servicesLoading } =
    useGetWashServicesQuery({
      status: "Active",
      page: 1,
      limit: 100,
    });

  // Load active, paid memberships for the Membership booking dropdown.
  const {
    data: membershipResponse,
    isLoading: membershipsLoading,
    isFetching: membershipsFetching,
    isError: membershipsError,
    refetch: refetchMemberships,
  } = useGetMembershipsQuery({
    status: "Active",
    paymentStatus: "Paid",
    societyId: form.societyId || undefined,
    flatId: form.flatId || undefined,
    carId: form.carId || undefined,
    page: 1,
    limit: 100,
  });

  const [createBooking, createState] = useCreateBookingMutation();

  const [changeStatus, changeStatusState] =
    useChangeBookingStatusMutation();

  const [deleteBooking, deleteState] = useDeleteBookingMutation();

  const societies = useMemo(
    () => getArray(societyResponse),
    [societyResponse],
  );

  const flats = useMemo(
    () => getArray(flatResponse),
    [flatResponse],
  );

  const cars = useMemo(
    () => getArray(carResponse),
    [carResponse],
  );

  const services = useMemo(
    () => getArray(serviceResponse),
    [serviceResponse],
  );

  const memberships = useMemo(
    () => getArray(membershipResponse),
    [membershipResponse],
  );

  const bookings = useMemo(
    () => getArray(bookingResponse),
    [bookingResponse],
  );

  const meta =
    (bookingResponse as AnyRecord | undefined)?.meta ??
    (bookingResponse as AnyRecord | undefined)?.data?.meta ??
    {};

  const totalPages = Math.max(
    1,
    Number(meta.totalPage ?? meta.totalPages ?? 1),
  );

  const totalRecords = Number(meta.total ?? bookings.length);

  const stats = useMemo(() => {
    return {
      total: totalRecords,
      pending: bookings.filter(
        (item) => item.status === "Pending",
      ).length,
      active: bookings.filter((item) =>
        ["Confirmed", "InProgress"].includes(item.status),
      ).length,
      completed: bookings.filter(
        (item) => item.status === "Completed",
      ).length,
    };
  }, [bookings, totalRecords]);

  const updateForm = <K extends keyof BookingForm>(
    key: K,
    value: BookingForm[K],
  ) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const openAddForm = () => {
    setSelectedBooking(null);
    setForm({ ...initialForm });
    setDialogMode("add");
    setActionError("");
    setFormOpen(true);
  };

  const openViewForm = (booking: AnyRecord) => {
    setSelectedBooking(booking);
    setDialogMode("view");
    setActionError("");
    setFormOpen(true);
  };

  const closeForm = () => {
    setFormOpen(false);
    setSelectedBooking(null);
    setActionError("");
  };

  const handleSubmit = async (
    event: React.FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();
    setActionError("");

    if (
      !form.societyId ||
      !form.flatId ||
      !form.carId ||
      !form.serviceId ||
      !form.bookingDate ||
      !form.bookingTime
    ) {
      setActionError("Complete all required fields.");
      return;
    }

    if (
      form.paymentType === "Membership" &&
      !form.membershipId
    ) {
      setActionError("Please select a membership.");
      return;
    }

    try {
      await createBooking({
        societyId: form.societyId,
        flatId: form.flatId,
        carId: form.carId,
        serviceId: form.serviceId,
        membershipId:
          form.paymentType === "Membership"
            ? form.membershipId
            : undefined,
        bookingDate: form.bookingDate,
        bookingTime: form.bookingTime,
        paymentType: form.paymentType,
        remarks: form.remarks.trim(),
      }).unwrap();

      toast.success("Booking created successfully.");

      closeForm();
      setForm({ ...initialForm });
      refetch();
    } catch (error: unknown) {
      setActionError(
        errorMessage(error, "Unable to create booking."),
      );
    }
  };

  const handleStatusChange = async (
    bookingId: string,
    nextStatus: BookingStatus,
  ) => {
    try {
      await changeStatus({
        id: bookingId,
        body: { status: nextStatus },
      }).unwrap();

      toast.success("Booking status updated.");
      refetch();
    } catch (error: unknown) {
      toast.error(
        errorMessage(error, "Unable to update booking status."),
      );
    }
  };

  const handleDelete = async () => {
    if (!selectedBooking) return;

    const bookingId = idOf(selectedBooking);

    if (!bookingId) {
      toast.error("Booking ID is missing.");
      return;
    }

    setActionError("");

    try {
      await deleteBooking(bookingId).unwrap();

      toast.success("Booking deleted successfully.");
      setDeleteOpen(false);
      setSelectedBooking(null);

      if (bookings.length === 1 && page > 1) {
        setPage((current) => current - 1);
      } else {
        refetch();
      }
    } catch (error: unknown) {
      setActionError(
        errorMessage(error, "Unable to delete booking."),
      );
    }
  };

  const exportCSV = () => {
    const headers = [
      "Booking ID",
      "Booking Date",
      "Booking Time",
      "Service",
      "Booking Type",
      "Amount",
      "Payment Status",
      "Booking Status",
    ];

    const rows = bookings.map((booking) => [
      idOf(booking),
      booking.bookingDate ?? "",
      booking.bookingTime ?? "",
      booking.serviceNameSnapshot ?? booking.serviceId?.name ?? "",
      booking.paymentType ?? "",
      booking.amountPayable ?? "",
      booking.paymentStatus ?? "",
      booking.status ?? "",
    ]);

    const escapeCSV = (value: unknown) =>
      `"${String(value ?? "").replace(/"/g, '""')}"`;

    const csv = [headers, ...rows]
      .map((row) => row.map(escapeCSV).join(","))
      .join("\r\n");

    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = "bookings.csv";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const filteredFlats = flats.filter((flat) => {
    const societyId = relationId(flat, [
      "societyId",
      "society",
      "society_id",
    ]);

    return !societyId || societyId === form.societyId;
  });

  const filteredCars = cars.filter((car) => {
    const societyId = relationId(car, [
      "societyId",
      "society",
      "society_id",
    ]);

    const flatId = relationId(car, [
      "flatId",
      "flat",
      "flat_id",
    ]);

    return (
      (!societyId || societyId === form.societyId) &&
      (!flatId || flatId === form.flatId)
    );
  });

  // Apply relation filtering on the frontend too.
  // This prevents unrelated memberships from appearing if the API
  // does not apply one of the optional query filters.
  const filteredMemberships = memberships.filter((membership) => {
    const societyId = relationId(membership, ["societyId", "society"]);
    const flatId = relationId(membership, ["flatId", "flat"]);
    const carId = relationId(membership, ["carId", "car"]);

    const isActive = membership.status === "Active";
    const isPaid = membership.paymentStatus === "Paid";
    const hasWashes =
      Number(membership.includedWashes ?? 0) -
        Number(membership.usedWashes ?? 0) -
        Number(membership.reservedWashes ?? 0) >
      0;

    return (
      isActive &&
      isPaid &&
      hasWashes &&
      (!societyId || societyId === form.societyId) &&
      (!flatId || flatId === form.flatId) &&
      (!carId || carId === form.carId)
    );
  });

  const loadingOptions =
    societiesLoading ||
    flatsLoading ||
    carsLoading ||
    servicesLoading;

  const membershipDropdownLoading =
    membershipsLoading || membershipsFetching;

  const membershipLabel = (membership: AnyRecord) => {
    const car = membership.carId;
    const plan = membership.planId;

    const registrationNumber =
      car?.registrationNumber ??
      car?.vehicleNumber ??
      "Car";

    const planName =
      plan?.name ??
      plan?.planName ??
      plan?.title ??
      "Membership Plan";

    const remainingWashes = Math.max(
      0,
      Number(membership.includedWashes ?? 0) -
        Number(membership.usedWashes ?? 0) -
        Number(membership.reservedWashes ?? 0),
    );

    return `${registrationNumber} | ${planName} | ${remainingWashes} washes left`;
  };

  return (
    <div className="space-y-6 p-6 md:p-10">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            Booking Management
          </h1>
          <p className="text-sm text-muted-foreground">
            Manage wash bookings, appointments and booking statuses.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={exportCSV}
            disabled={bookings.length === 0}
          >
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>

          <Button
            variant="outline"
            onClick={() => refetch()}
            disabled={isFetching}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>

          <Button onClick={openAddForm}>
            <Plus className="mr-2 h-4 w-4" />
            Add Booking
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              Total Bookings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold">{stats.total}</p>
              <CalendarCheck className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              Pending
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold text-amber-600">
                {stats.pending}
              </p>
              <Clock className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              Confirmed / In Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-600">
              {stats.active}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              Completed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold text-green-600">
                {stats.completed}
              </p>
              <CheckCircle2 className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Bookings</CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-9"
                placeholder="Search bookings..."
                value={searchTerm}
                onChange={(event) => {
                  setSearchTerm(event.target.value);
                  setPage(1);
                }}
              />
            </div>

            <Select
              value={statusFilter}
              onValueChange={(value) => {
                setStatusFilter(value);
                setPage(1);
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Statuses</SelectItem>
                {bookingStatuses.map((status) => (
                  <SelectItem key={status} value={status}>
                    {status}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isLoading ? (
            <div className="py-10 text-center text-muted-foreground">
              Loading bookings...
            </div>
          ) : isError ? (
            <div className="space-y-3 py-10 text-center">
              <p className="text-sm text-red-600">
                Failed to load bookings.
              </p>
              <Button variant="outline" onClick={() => refetch()}>
                Try Again
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date / Time</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Payment</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>

                <TableBody>
                  {bookings.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={7}
                        className="h-24 text-center text-muted-foreground"
                      >
                        No bookings found.
                      </TableCell>
                    </TableRow>
                  ) : (
                    bookings.map((booking, index) => {
                      const bookingId = idOf(booking);

                      return (
                        <TableRow key={bookingId || index}>
                          <TableCell>
                            {formatDate(booking.bookingDate)}
                            <div className="text-xs text-muted-foreground">
                              {booking.bookingTime || "—"}
                            </div>
                          </TableCell>

                          <TableCell>
                            <div className="font-medium">
                              {booking.serviceNameSnapshot ??
                                booking.serviceId?.name ??
                                "—"}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {booking.bookingNumber
                                ? `#${booking.bookingNumber}`
                                : bookingId}
                            </div>
                          </TableCell>

                          <TableCell>
                            {booking.paymentType || "—"}
                          </TableCell>

                          <TableCell>
                            ₹
                            {Number(
                              booking.amountPayable ?? 0,
                            ).toFixed(2)}
                          </TableCell>

                          <TableCell>
                            {booking.paymentStatus || "—"}
                          </TableCell>

                          <TableCell>
                            <span
                              className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${statusClass(
                                booking.status || "Pending",
                              )}`}
                            >
                              {booking.status || "Pending"}
                            </span>
                          </TableCell>

                          <TableCell>
                            <div className="flex flex-wrap justify-end gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                title="View Booking"
                                onClick={() => openViewForm(booking)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>

                              <Select
                                value={booking.status || "Pending"}
                                onValueChange={(value: BookingStatus) =>
                                  handleStatusChange(bookingId, value)
                                }
                                disabled={
                                  !bookingId ||
                                  changeStatusState.isLoading ||
                                  ["Completed", "Cancelled"].includes(
                                    booking.status,
                                  )
                                }
                              >
                                <SelectTrigger className="h-8 w-36">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {bookingStatuses.map((status) => (
                                    <SelectItem
                                      key={status}
                                      value={status}
                                    >
                                      {status}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>

                              <Button
                                variant="ghost"
                                size="icon"
                                title="Delete Booking"
                                className="text-red-600 hover:text-red-700"
                                disabled={!bookingId || deleteState.isLoading}
                                onClick={() => {
                                  setSelectedBooking(booking);
                                  setActionError("");
                                  setDeleteOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          )}

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <span className="text-sm text-muted-foreground">
              Page {Number(meta.page ?? page)} of {totalPages}
              {" · "}
              {totalRecords} records
              {isFetching ? " · Refreshing..." : ""}
            </span>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page <= 1 || isFetching}
                onClick={() =>
                  setPage((current) => Math.max(1, current - 1))
                }
              >
                Previous
              </Button>

              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages || isFetching}
                onClick={() =>
                  setPage((current) =>
                    Math.min(totalPages, current + 1),
                  )
                }
              >
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Dialog
        open={formOpen}
        onOpenChange={(open) => {
          if (!open) closeForm();
          else setFormOpen(true);
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              {dialogMode === "add" ? "Add Booking" : "Booking Details"}
            </DialogTitle>
            <DialogDescription>
              {dialogMode === "add"
                ? "Create a new car wash booking."
                : "Review the selected booking information."}
            </DialogDescription>
          </DialogHeader>

          {dialogMode === "add" ? (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Society *</Label>
                  <Select
                    value={form.societyId}
                    onValueChange={(value) =>
                      setForm((current) => ({
                        ...current,
                        societyId: value,
                        flatId: "",
                        carId: "",
                        membershipId: "",
                      }))
                    }
                    disabled={societiesLoading}
                  >
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          societiesLoading
                            ? "Loading societies..."
                            : "Select society"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {societies.map((society, index) => {
                        const id = idOf(society);
                        if (!id) return null;

                        return (
                          <SelectItem key={id || index} value={id}>
                            {labelOf(society, [
                              "name",
                              "societyName",
                              "title",
                            ])}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Flat *</Label>
                  <Select
                    value={form.flatId}
                    onValueChange={(value) =>
                      setForm((current) => ({
                        ...current,
                        flatId: value,
                        carId: "",
                        membershipId: "",
                      }))
                    }
                    disabled={!form.societyId || flatsLoading}
                  >
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          !form.societyId
                            ? "Select society first"
                            : flatsLoading
                              ? "Loading flats..."
                              : "Select flat"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredFlats.map((flat, index) => {
                        const id = idOf(flat);
                        if (!id) return null;

                        return (
                          <SelectItem key={id || index} value={id}>
                            {labelOf(flat, [
                              "flatNo",
                              "flatNumber",
                              "unitNumber",
                              "name",
                              "title",
                            ])}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Car *</Label>
                  <Select
                    value={form.carId}
                    onValueChange={(value) =>
                      setForm((current) => ({
                        ...current,
                        carId: value,
                        membershipId: "",
                      }))
                    }
                    disabled={!form.flatId || carsLoading}
                  >
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          !form.flatId
                            ? "Select flat first"
                            : carsLoading
                              ? "Loading cars..."
                              : "Select car"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredCars.map((car, index) => {
                        const id = idOf(car);
                        if (!id) return null;

                        return (
                          <SelectItem key={id || index} value={id}>
                            {labelOf(car, [
                              "registrationNumber",
                              "vehicleNumber",
                              "carNumber",
                              "registrationNo",
                              "name",
                              "model",
                            ])}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Wash Service *</Label>
                  <Select
                    value={form.serviceId}
                    onValueChange={(value) =>
                      updateForm("serviceId", value)
                    }
                    disabled={servicesLoading}
                  >
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          servicesLoading
                            ? "Loading services..."
                            : "Select wash service"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service, index) => {
                        const id = idOf(service);
                        if (!id) return null;

                        return (
                          <SelectItem key={id || index} value={id}>
                            {labelOf(service, ["name", "title"])} — ₹
                            {Number(service.price ?? 0).toFixed(2)} (
                            {service.durationMinutes ?? "—"} min)
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Booking Date *</Label>
                  <Input
                    type="date"
                    value={form.bookingDate}
                    min={new Date().toLocaleDateString("en-CA")}
                    onChange={(event) =>
                      updateForm("bookingDate", event.target.value)
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Booking Time *</Label>
                  <Input
                    type="time"
                    value={form.bookingTime}
                    onChange={(event) =>
                      updateForm("bookingTime", event.target.value)
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Booking Type *</Label>
                  <Select
                    value={form.paymentType}
                    onValueChange={(value: PaymentType) =>
                      setForm((current) => ({
                        ...current,
                        paymentType: value,
                        membershipId: "",
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Individual">
                        Individual paid booking
                      </SelectItem>
                      <SelectItem value="Membership">
                        Membership-included wash
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {form.paymentType === "Membership" && (
                  <div className="space-y-2 sm:col-span-2">
                    <div className="flex items-center justify-between gap-2">
                      <Label>Membership ID *</Label>

                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => refetchMemberships()}
                        disabled={membershipDropdownLoading}
                      >
                        <RefreshCw className="mr-2 h-3.5 w-3.5" />
                        Refresh
                      </Button>
                    </div>

                    <Select
                      value={form.membershipId}
                      onValueChange={(value) =>
                        updateForm("membershipId", value)
                      }
                      disabled={
                        !form.societyId ||
                        !form.flatId ||
                        !form.carId ||
                        membershipDropdownLoading ||
                        membershipsError
                      }
                    >
                      <SelectTrigger>
                        <SelectValue
                          placeholder={
                            !form.societyId
                              ? "Select society first"
                              : !form.flatId
                                ? "Select flat first"
                                : !form.carId
                                  ? "Select car first"
                                  : membershipDropdownLoading
                                    ? "Loading memberships..."
                                    : membershipsError
                                      ? "Unable to load memberships"
                                      : "Select membership"
                          }
                        />
                      </SelectTrigger>

                      <SelectContent>
                        {filteredMemberships.map((membership) => {
                          const id = idOf(membership);

                          if (!id) return null;

                          return (
                            <SelectItem key={id} value={id}>
                              {membershipLabel(membership)}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>

                    {membershipsError && (
                      <p className="text-sm text-red-600">
                        Failed to load memberships. Click Refresh to retry.
                      </p>
                    )}

                    {!membershipDropdownLoading &&
                      !membershipsError &&
                      form.societyId &&
                      form.flatId &&
                      form.carId &&
                      filteredMemberships.length === 0 && (
                        <p className="text-sm text-amber-600">
                          No eligible paid membership with available washes
                          was found for this car.
                        </p>
                      )}

                    <p className="text-xs text-muted-foreground">
                      Only active, paid memberships with available washes
                      are listed for the selected society, flat and car.
                    </p>
                  </div>
                )}

                <div className="space-y-2 sm:col-span-2">
                  <Label>Remarks</Label>
                  <Textarea
                    value={form.remarks}
                    onChange={(event) =>
                      updateForm("remarks", event.target.value)
                    }
                    placeholder="Optional booking remarks"
                    maxLength={1000}
                  />
                </div>
              </div>

              {actionError && (
                <p role="alert" className="text-sm text-red-600">
                  {actionError}
                </p>
              )}

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={closeForm}
                >
                  Cancel
                </Button>

                <Button
                  type="submit"
                  disabled={
                    createState.isLoading ||
                    loadingOptions ||
                    (form.paymentType === "Membership" &&
                      membershipDropdownLoading)
                  }
                >
                  {createState.isLoading
                    ? "Creating..."
                    : "Create Booking"}
                </Button>
              </DialogFooter>
            </form>
          ) : (
            <>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {[
                  ["Booking ID", idOf(selectedBooking)],
                  [
                    "Booking Date",
                    formatDate(selectedBooking?.bookingDate),
                  ],
                  ["Booking Time", selectedBooking?.bookingTime],
                  [
                    "Service",
                    selectedBooking?.serviceNameSnapshot ??
                      selectedBooking?.serviceId?.name,
                  ],
                  ["Booking Type", selectedBooking?.paymentType],
                  [
                    "Amount",
                    `₹${Number(
                      selectedBooking?.amountPayable ?? 0,
                    ).toFixed(2)}`,
                  ],
                  ["Payment Status", selectedBooking?.paymentStatus],
                  ["Booking Status", selectedBooking?.status],
                  [
                    "Membership ID",
                    idOf(selectedBooking?.membershipId) || "—",
                  ],
                  ["Remarks", selectedBooking?.remarks || "—"],
                ].map(([label, value]) => (
                  <div key={label} className="space-y-1">
                    <Label className="text-muted-foreground">
                      {label}
                    </Label>
                    <p className="break-words text-sm font-medium">
                      {value || "—"}
                    </p>
                  </div>
                ))}
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={closeForm}>
                  Close
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Dialog
        open={deleteOpen}
        onOpenChange={(open) => {
          setDeleteOpen(open);
          if (!open) setActionError("");
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Booking</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this booking? This action
              cannot be undone.
            </DialogDescription>
          </DialogHeader>

          {actionError && (
            <p role="alert" className="text-sm text-red-600">
              {actionError}
            </p>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteOpen(false)}
              disabled={deleteState.isLoading}
            >
              Cancel
            </Button>

            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteState.isLoading}
            >
              {deleteState.isLoading ? "Deleting..." : "Delete Booking"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BookingPage;
