
import React, { useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  CarFront,
  Clock3,
  RefreshCw,
  Search,
  ClipboardList,
  MapPin,
  Play,
  Pause,
  CheckCircle2,
  RotateCcw,
  Timer,
  AlertCircle,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { useGetWorkerAssignedBookingsQuery } from "@/redux/features/worker/workerApi";
import { baseApi } from "@/redux/api/baseApi";

// If your base API export has a different name, use the same API
// instance that exports useGetWorkerAssignedBookingsQuery.

type TWorkStatus = "NotStarted" | "Working" | "Paused" | "Completed";

type TBooking = {
  _id: string;
  bookingId?: string;
  status?: string;
  bookingDate?: string;
  bookingTime?: string;
  amountPayable?: number;
  servicePriceSnapshot?: number;

  workStatus?: TWorkStatus;
  currentWorkStartedAt?: string | null;
  totalWorkingSeconds?: number;
  workCompletedAt?: string | null;

  societyId?: {
    name?: string;
    societyName?: string;
  } | string;

  flatId?: {
    flatNumber?: string;
    name?: string;
  } | string;

  carId?: {
    brand?: string;
    model?: string;
    carNumber?: string;
    registrationNumber?: string;
  } | string;

  serviceId?: {
    name?: string;
    serviceName?: string;
  } | string;
};

type TApiResponse = {
  success?: boolean;
  message?: string;
  data?: unknown;
};

const getErrorMessage = (error: any) =>
  error?.data?.message ||
  error?.error ||
  "Unable to process the request. Please try again.";

const getObjectName = (
  value: TBooking["societyId"] | TBooking["serviceId"],
) => {
  if (!value) return "—";
  if (typeof value === "string") return value;

  return (
    value.name ||
    ("societyName" in value ? value.societyName : undefined) ||
    ("serviceName" in value ? value.serviceName : undefined) ||
    "—"
  );
};

const getFlatName = (value: TBooking["flatId"]) => {
  if (!value) return "—";
  if (typeof value === "string") return value;

  return value.flatNumber || value.name || "—";
};

const getCarName = (value: TBooking["carId"]) => {
  if (!value) return "—";
  if (typeof value === "string") return value;

  const name = [value.brand, value.model].filter(Boolean).join(" ");

  return (
    [name, value.carNumber || value.registrationNumber]
      .filter(Boolean)
      .join(" · ") || "—"
  );
};

const formatDate = (value?: string) => {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const formatWorkingTime = (seconds = 0) => {
  const safeSeconds = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(safeSeconds / 3600);
  const minutes = Math.floor((safeSeconds % 3600) / 60);
  const remainingSeconds = safeSeconds % 60;

  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(
    2,
    "0",
  )}:${String(remainingSeconds).padStart(2, "0")}`;
};

const getWorkStatus = (booking: TBooking): TWorkStatus => {
  if (booking.workStatus) return booking.workStatus;

  if (booking.status === "Completed") return "Completed";

  return "NotStarted";
};

const statusClass = (status?: string) => {
  switch ((status || "").toLowerCase()) {
    case "completed":
      return "bg-green-100 text-green-700";
    case "inprogress":
      return "bg-blue-100 text-blue-700";
    case "confirmed":
      return "bg-blue-100 text-blue-700";
    case "pending":
      return "bg-amber-100 text-amber-700";
    case "cancelled":
      return "bg-red-100 text-red-700";
    default:
      return "bg-gray-100 text-gray-700";
  }
};

const workStatusClass = (status: TWorkStatus) => {
  switch (status) {
    case "Working":
      return "bg-emerald-100 text-emerald-700";
    case "Paused":
      return "bg-amber-100 text-amber-700";
    case "Completed":
      return "bg-green-100 text-green-700";
    default:
      return "bg-slate-100 text-slate-700";
  }
};

const AssignedBookings: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [now, setNow] = useState(Date.now());
  const [actionError, setActionError] = useState("");
  const [processingBookingId, setProcessingBookingId] = useState("");

  const {
    data: response,
    isLoading,
    isFetching,
    isError,
    error,
    refetch,
  } = useGetWorkerAssignedBookingsQuery();

  // Use your existing API slice instance for the work-action mutation.
  const [updateWorkAction, { isLoading: isUpdating }] =
    baseApi.useUpdateWorkerBookingWorkActionMutation();

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);

    return () => clearInterval(interval);
  }, []);

  const bookings: TBooking[] = useMemo(() => {
    const result = response as any;

    if (Array.isArray(result)) return result;
    if (Array.isArray(result?.data)) return result.data;
    if (Array.isArray(result?.data?.data)) return result.data.data;

    return [];
  }, [response]);

  const filteredBookings = useMemo(() => {
    const search = searchTerm.trim().toLowerCase();

    return bookings.filter((booking) => {
      const values = [
        booking.bookingId,
        booking._id,
        booking.status,
        booking.workStatus,
        getObjectName(booking.societyId),
        getFlatName(booking.flatId),
        getCarName(booking.carId),
        getObjectName(booking.serviceId),
      ];

      const matchesSearch =
        !search ||
        values.some((value) =>
          String(value || "").toLowerCase().includes(search),
        );

      const matchesStatus =
        statusFilter === "all" ||
        (booking.status || "").toLowerCase() === statusFilter.toLowerCase();

      return matchesSearch && matchesStatus;
    });
  }, [bookings, searchTerm, statusFilter]);

  const pendingCount = bookings.filter((booking) =>
    ["pending", "confirmed"].includes(
      (booking.status || "").toLowerCase(),
    ),
  ).length;

  const completedCount = bookings.filter(
    (booking) => booking.status === "Completed",
  ).length;

  const cancelledCount = bookings.filter(
    (booking) => booking.status === "Cancelled",
  ).length;

  const getElapsedSeconds = (booking: TBooking) => {
    const accumulated = booking.totalWorkingSeconds || 0;

    if (
      getWorkStatus(booking) !== "Working" ||
      !booking.currentWorkStartedAt
    ) {
      return accumulated;
    }

    const startedAt = new Date(booking.currentWorkStartedAt).getTime();

    if (Number.isNaN(startedAt)) return accumulated;

    return accumulated + Math.max(0, Math.floor((now - startedAt) / 1000));
  };

  const handleWorkAction = async (
    booking: TBooking,
    action: "start" | "stop" | "resume" | "done",
  ) => {
    setActionError("");
    setProcessingBookingId(booking._id);

    try {
      await updateWorkAction({
        id: booking._id,
        action,
      }).unwrap();

      await refetch();
    } catch (err: any) {
      setActionError(
        err?.data?.message ||
          err?.data?.error ||
          err?.error ||
          `Unable to ${action} work. Please try again.`,
      );
    } finally {
      setProcessingBookingId("");
    }
  };

  const renderWorkActions = (booking: TBooking) => {
    const workStatus = getWorkStatus(booking);
    const busy = isUpdating && processingBookingId === booking._id;

    if (booking.status === "Cancelled" || booking.status === "Completed") {
      return (
        <span className="text-xs text-muted-foreground">
          No actions available
        </span>
      );
    }

    if (workStatus === "Completed") {
      return (
        <span className="inline-flex items-center gap-1 text-sm font-medium text-green-700">
          <CheckCircle2 className="h-4 w-4" />
          Work Done
        </span>
      );
    }

    if (workStatus === "NotStarted") {
      return (
        <Button
          size="sm"
          disabled={busy || isUpdating || booking.status !== "Confirmed"}
          onClick={() => handleWorkAction(booking, "start")}
        >
          <Play className="mr-1 h-4 w-4" />
          Start Work
        </Button>
      );
    }

    if (workStatus === "Working") {
      return (
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            variant="outline"
            disabled={busy || isUpdating}
            onClick={() => handleWorkAction(booking, "stop")}
          >
            <Pause className="mr-1 h-4 w-4" />
            Stop Work
          </Button>

          <Button
            size="sm"
            disabled={busy || isUpdating}
            onClick={() => {
              if (
                window.confirm(
                  "Are you sure you have completed this booking?",
                )
              ) {
                void handleWorkAction(booking, "done");
              }
            }}
          >
            <CheckCircle2 className="mr-1 h-4 w-4" />
            Done Work
          </Button>
        </div>
      );
    }

    if (workStatus === "Paused") {
      return (
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            disabled={busy || isUpdating}
            onClick={() => handleWorkAction(booking, "resume")}
          >
            <RotateCcw className="mr-1 h-4 w-4" />
            Resume
          </Button>

          <Button
            size="sm"
            variant="outline"
            disabled={busy || isUpdating}
            onClick={() => {
              if (
                window.confirm(
                  "Are you sure you have completed this booking?",
                )
              ) {
                void handleWorkAction(booking, "done");
              }
            }}
          >
            <CheckCircle2 className="mr-1 h-4 w-4" />
            Done Work
          </Button>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="space-y-6 p-4 md:p-8">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            Assigned Bookings
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Manage assigned jobs and track your working hours.
          </p>
        </div>

        <Button
          variant="outline"
          onClick={() => refetch()}
          disabled={isFetching}
        >
          <RefreshCw
            className={`mr-2 h-4 w-4 ${isFetching ? "animate-spin" : ""}`}
          />
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              Total Assigned
            </CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <span className="text-2xl font-bold">{bookings.length}</span>
            <ClipboardList className="h-5 w-5 text-muted-foreground" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              Pending / Confirmed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold text-amber-600">
              {pendingCount}
            </span>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold text-green-600">
              {completedCount}
            </span>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Cancelled</CardTitle>
          </CardHeader>
          <CardContent>
            <span className="text-2xl font-bold text-red-600">
              {cancelledCount}
            </span>
          </CardContent>
        </Card>
      </div>

      {actionError && (
        <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{actionError}</span>
          <button
            type="button"
            className="ml-auto font-semibold"
            onClick={() => setActionError("")}
          >
            Dismiss
          </button>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Booking List</CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_220px]">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-9"
                placeholder="Search booking, car, society, service..."
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="confirmed">Confirmed</SelectItem>
                <SelectItem value="inprogress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isLoading ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              Loading assigned bookings...
            </div>
          ) : isError ? (
            <div className="space-y-3 py-10 text-center">
              <p className="text-sm text-red-600">
                {getErrorMessage(error)}
              </p>
              <Button variant="outline" onClick={() => refetch()}>
                Try Again
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Booking</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Society / Flat</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Booking Status</TableHead>
                    <TableHead>Work Status</TableHead>
                    <TableHead>Working Hours</TableHead>
                    <TableHead>Work Actions</TableHead>
                  </TableRow>
                </TableHeader>

                <TableBody>
                  {filteredBookings.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={9}
                        className="h-28 text-center text-muted-foreground"
                      >
                        {bookings.length === 0
                          ? "No bookings are assigned to you yet."
                          : "No bookings match your search or status filter."}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredBookings.map((booking) => {
                      const workStatus = getWorkStatus(booking);

                      return (
                        <TableRow key={booking._id}>
                          <TableCell>
                            <div className="font-medium">
                              {booking.bookingId || booking._id.slice(-8)}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              ID: {booking._id}
                            </div>
                          </TableCell>

                          <TableCell>
                            {getObjectName(booking.serviceId)}
                          </TableCell>

                          <TableCell>
                            <div className="flex items-center gap-2">
                              <CarFront className="h-4 w-4 text-muted-foreground" />
                              <span>{getCarName(booking.carId)}</span>
                            </div>
                          </TableCell>

                          <TableCell>
                            <div className="font-medium">
                              {getObjectName(booking.societyId)}
                            </div>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <MapPin className="h-3 w-3" />
                              Flat: {getFlatName(booking.flatId)}
                            </div>
                          </TableCell>

                          <TableCell>
                            <div className="flex items-center gap-2">
                              <CalendarDays className="h-4 w-4 text-muted-foreground" />
                              {formatDate(booking.bookingDate)}
                            </div>
                            <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                              <Clock3 className="h-3 w-3" />
                              {booking.bookingTime || "—"}
                            </div>
                          </TableCell>

                          <TableCell>
                            <span
                              className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${statusClass(
                                booking.status,
                              )}`}
                            >
                              {booking.status || "Unknown"}
                            </span>
                          </TableCell>

                          <TableCell>
                            <span
                              className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${workStatusClass(
                                workStatus,
                              )}`}
                            >
                              {workStatus}
                            </span>
                          </TableCell>

                          <TableCell>
                            <div className="flex items-center gap-2 font-mono text-sm font-semibold">
                              <Timer className="h-4 w-4 text-muted-foreground" />
                              {formatWorkingTime(getElapsedSeconds(booking))}
                            </div>
                            {workStatus === "Working" && (
                              <span className="mt-1 block text-xs text-emerald-600">
                                Timer running
                              </span>
                            )}
                          </TableCell>

                          <TableCell className="min-w-[220px]">
                            {renderWorkActions(booking)}
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          )}

          {isFetching && !isLoading && (
            <p className="text-xs text-muted-foreground">
              Refreshing bookings...
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AssignedBookings;
