import { useEffect, useMemo, useState } from "react";
import { CalendarDays, CarFront, Clock3, Droplets, RefreshCw } from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { useGetMyCarsQuery, type TCar } from "@/redux/features/car/carApi";
import {
  useCreateBookingMutation,
  useGetBookingsQuery,
  type BookingNew,
} from "@/redux/features/bookingNew/bookingNewApi";
import {
  useGetWashServicesQuery,
  type WashService,
} from "@/redux/features/washService/washServiceApi";
import {
  useGetWashServiceSlotsQuery,
  type TAvailableSlot,
} from "@/redux/features/slots/slots";

type RelatedValue =
  | string
  | {
      _id?: string;
      id?: string;
      name?: string;
      city?: string;
      flatNumber?: string;
      block?: string;
      registrationNumber?: string;
      make?: string;
      model?: string;
    };

type CustomerCar = TCar & {
  societyId: RelatedValue;
  flatId: RelatedValue;
};

type CustomerBooking = BookingNew;

type ApiEnvelope<T> = {
  data?: T | { data?: T; result?: T; results?: T; docs?: T; items?: T };
  result?: T;
  results?: T;
  docs?: T;
  items?: T;
};

type BookingForm = {
  carId: string;
  serviceId: string;
  bookingDate: string;
  bookingTime: string;
  slotId: string;
  remarks: string;
};

const emptyForm: BookingForm = {
  carId: "",
  serviceId: "",
  bookingDate: "",
  bookingTime: "",
  slotId: "",
  remarks: "",
};

const getArray = <T,>(response: unknown): T[] => {
  if (Array.isArray(response)) return response as T[];
  if (!response || typeof response !== "object") return [];

  const envelope = response as ApiEnvelope<T[]>;
  const candidates = [
    envelope.data,
    envelope.result,
    envelope.results,
    envelope.docs,
    envelope.items,
  ];

  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return candidate;
    if (candidate && typeof candidate === "object") {
      const nested = candidate as Record<string, unknown>;
      for (const value of [
        nested.data,
        nested.result,
        nested.results,
        nested.docs,
        nested.items,
      ]) {
        if (Array.isArray(value)) return value;
      }
    }
  }

  return [];
};

const idOf = (value: unknown): string => {
  if (typeof value === "string") return value;
  if (!value || typeof value !== "object") return "";
  const record = value as { _id?: string; id?: string };
  return record._id || record.id || "";
};

const labelOf = (value: unknown): string => {
  if (typeof value === "string") return value;
  if (!value || typeof value !== "object") return "—";

  const record = value as Record<string, unknown>;
  if (typeof record.registrationNumber === "string") {
    return record.registrationNumber;
  }
  if (typeof record.name === "string") return record.name;
  if (typeof record.flatNumber === "string") {
    return `${record.block ? `${record.block} · ` : ""}${record.flatNumber}`;
  }
  if (typeof record.make === "string" || typeof record.model === "string") {
    return [record.make, record.model].filter(Boolean).join(" ");
  }
  return "—";
};

const formatDate = (value: string) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "—"
    : date.toLocaleDateString(undefined, {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
};

const statusClass = (status: string) => {
  switch (status) {
    case "Confirmed":
    case "Completed":
      return "border-emerald-200 bg-emerald-50 text-emerald-700";
    case "InProgress":
      return "border-blue-200 bg-blue-50 text-blue-700";
    case "Cancelled":
      return "border-red-200 bg-red-50 text-red-700";
    default:
      return "border-amber-200 bg-amber-50 text-amber-700";
  }
};

const today = () => {
  const date = new Date();
  const localDate = new Date(
    date.getTime() - date.getTimezoneOffset() * 60_000,
  );
  return localDate.toISOString().slice(0, 10);
};

const toLocalDateInput = (date: Date) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(
    date.getDate(),
  ).padStart(2, "0")}`;

type CustomerBookingsProps = {
  openBookingOnLoad?: boolean;
};

const CustomerBookings = ({
  openBookingOnLoad = false,
}: CustomerBookingsProps) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<BookingForm>({ ...emptyForm });
  const [formError, setFormError] = useState("");
  const [calendarMonth, setCalendarMonth] = useState(() => {
    const currentDate = new Date();
    return new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  });

  useEffect(() => {
    if (openBookingOnLoad) setDialogOpen(true);
  }, [openBookingOnLoad]);

  const {
    data: bookingsResponse,
    isLoading: bookingsLoading,
    isFetching: bookingsFetching,
    isError: bookingsError,
    refetch: refetchBookings,
  } = useGetBookingsQuery({ page: 1, limit: 100 });
  const {
    data: carsResponse,
    isLoading: carsLoading,
    isError: carsError,
    refetch: refetchCars,
  } = useGetMyCarsQuery();
  const {
    data: servicesResponse,
    isLoading: servicesLoading,
    isError: servicesError,
    refetch: refetchServices,
  } = useGetWashServicesQuery({ status: "Active", page: 1, limit: 100 });
  const monthStart = toLocalDateInput(
    new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), 1),
  );
  const monthEnd = toLocalDateInput(
    new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 0),
  );
  const {
    data: slotsResponse,
    isFetching: slotsFetching,
    isError: slotsError,
    refetch: refetchSlots,
  } = useGetWashServiceSlotsQuery(
    { serviceId: form.serviceId, from: monthStart, to: monthEnd },
    { skip: !form.serviceId },
  );
  const [createBooking, createState] = useCreateBookingMutation();

  const bookings = useMemo(
    () => getArray<CustomerBooking>(bookingsResponse),
    [bookingsResponse],
  );
  const totalBookings =
    bookingsResponse?.data?.meta?.total ?? bookings.length;
  const verifiedCars = useMemo(
    () =>
      getArray<CustomerCar>(carsResponse).filter(
        (car) =>
          car.verificationStatus === "VERIFIED" && car.status === "Active",
      ),
    [carsResponse],
  );
  const services = useMemo(
    () =>
      getArray<WashService>(servicesResponse).filter(
        (service) => service.status === "Active",
      ),
    [servicesResponse],
  );
  const slots = useMemo(
    () => slotsResponse?.data ?? [],
    [slotsResponse],
  );
  const availableSlotDates = useMemo(
    () =>
      new Set(
        slots
          .filter((slot) => slot.isBooked === "available")
          .map((slot) => slot.date.slice(0, 10)),
      ),
    [slots],
  );
  const selectedDateSlots = useMemo(
    () => slots.filter((slot) => slot.date.slice(0, 10) === form.bookingDate),
    [slots, form.bookingDate],
  );

  const openForm = () => {
    setForm({ ...emptyForm });
    setFormError("");
    setDialogOpen(true);
  };

  const closeForm = () => {
    if (createState.isLoading) return;
    setDialogOpen(false);
    setFormError("");
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError("");

    const selectedCar = verifiedCars.find((car) => car._id === form.carId);
    if (!selectedCar || !idOf(selectedCar.societyId) || !idOf(selectedCar.flatId)) {
      setFormError("Choose one of your verified cars with its flat and society.");
      return;
    }
    if (!form.serviceId || !form.bookingDate || !form.slotId || !form.bookingTime) {
      setFormError("Select a service, date and available time slot.");
      return;
    }

    try {
      await createBooking({
        societyId: idOf(selectedCar.societyId),
        flatId: idOf(selectedCar.flatId),
        carId: selectedCar._id,
        serviceId: form.serviceId,
        slotId: form.slotId,
        bookingDate: form.bookingDate,
        bookingTime: form.bookingTime,
        paymentType: "Individual",
        remarks: form.remarks.trim(),
      }).unwrap();

      toast.success("Your car wash has been booked.");
      setDialogOpen(false);
      setForm({ ...emptyForm });
      refetchBookings();
    } catch (error) {
      const response = error as {
        data?: { message?: string; error?: { message?: string } };
      };
      setFormError(
        response.data?.message ||
          response.data?.error?.message ||
          "Unable to create your booking. Please try again.",
      );
    }
  };

  const retryLoad = () => {
    refetchBookings();
    refetchCars();
    refetchServices();
    if (form.serviceId) refetchSlots();
  };

  const loading = bookingsLoading || carsLoading || servicesLoading;
  const hasLoadError = bookingsError || carsError || servicesError;

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            My Bookings
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Book a wash for your verified car and follow its progress.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={retryLoad}
            disabled={bookingsFetching}
          >
            <RefreshCw
              className={`mr-2 h-4 w-4 ${bookingsFetching ? "animate-spin" : ""}`}
            />
            Refresh
          </Button>
          <Button type="button" onClick={openForm}>
            <Droplets className="mr-2 h-4 w-4" />
            Book a Wash
          </Button>
        </div>
      </div>

      {hasLoadError && (
        <div className="flex flex-col gap-3 rounded-xl border border-red-200 bg-red-50 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-medium text-red-800">
              Unable to load your booking information
            </p>
            <p className="mt-1 text-sm text-red-700">
              Please check your connection and try again.
            </p>
          </div>
          <Button variant="outline" onClick={retryLoad}>
            Try again
          </Button>
        </div>
      )}

      {verifiedCars.length === 0 && !carsLoading && !carsError && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          Add a car and wait for it to be verified before booking a wash.
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ["Total bookings", totalBookings],
          ["Pending", bookings.filter((booking) => booking.status === "Pending").length],
          [
            "In progress",
            bookings.filter((booking) =>
              ["Confirmed", "InProgress"].includes(booking.status),
            ).length,
          ],
          ["Completed", bookings.filter((booking) => booking.status === "Completed").length],
        ].map(([title, count]) => (
          <Card key={title}>
            <CardHeader className="pb-2">
              <CardDescription>{title}</CardDescription>
              <CardTitle className="text-2xl">
                {loading ? "…" : count}
              </CardTitle>
            </CardHeader>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Booking history</CardTitle>
          <CardDescription>
            Your appointments, service details and current status.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {bookingsLoading ? (
            <p className="py-10 text-center text-sm text-slate-500">
              Loading your bookings…
            </p>
          ) : bookings.length === 0 ? (
            <div className="flex flex-col items-center py-10 text-center">
              <CalendarDays className="h-10 w-10 text-slate-300" />
              <h2 className="mt-3 font-semibold text-slate-800">
                No bookings yet
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Schedule your first car wash to see it here.
              </p>
              <Button
                className="mt-4"
                onClick={openForm}
                disabled={verifiedCars.length === 0}
              >
                Book a Wash
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {bookings.map((booking) => (
                <div
                  key={booking._id}
                  className="flex flex-col gap-4 rounded-lg border border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-semibold text-slate-900">
                        {booking.serviceNameSnapshot || labelOf(booking.serviceId)}
                      </h2>
                      <Badge
                        variant="outline"
                        className={statusClass(booking.status)}
                      >
                        {booking.status === "InProgress"
                          ? "In progress"
                          : booking.status}
                      </Badge>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-slate-500">
                      <span className="inline-flex items-center gap-1.5">
                        <CarFront className="h-4 w-4" />
                        {labelOf(booking.carId)}
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <CalendarDays className="h-4 w-4" />
                        {formatDate(booking.bookingDate)}
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Clock3 className="h-4 w-4" />
                        {booking.bookingTime}
                      </span>
                      <span>{labelOf(booking.societyId)} · {labelOf(booking.flatId)}</span>
                    </div>
                  </div>
                  <div className="shrink-0 text-left sm:text-right">
                    <p className="font-semibold text-slate-900">
                      {booking.amountPayable === 0
                        ? "Covered by membership"
                        : `₹${booking.amountPayable}`}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      Payment: {booking.paymentStatus}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={(open) => {
        if (open) setDialogOpen(true);
        else closeForm();
      }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
          <form onSubmit={handleSubmit} className="space-y-5">
            <DialogHeader>
              <DialogTitle>Book a car wash</DialogTitle>
              <DialogDescription>
                Select a verified car and an active service to schedule your wash.
              </DialogDescription>
            </DialogHeader>

            {formError && (
              <div
                role="alert"
                className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700"
              >
                {formError}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="booking-car">Car *</Label>
              <Select
                value={form.carId}
                onValueChange={(carId) =>
                  setForm((current) => ({ ...current, carId }))
                }
              >
                <SelectTrigger id="booking-car">
                  <SelectValue placeholder="Choose your verified car" />
                </SelectTrigger>
                <SelectContent>
                  {verifiedCars.map((car) => (
                    <SelectItem key={car._id} value={car._id}>
                      {[car.registrationNumber, car.make, car.model]
                        .filter(Boolean)
                        .join(" · ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.carId && (
                <p className="text-xs text-slate-500">
                  {labelOf(
                    verifiedCars.find((car) => car._id === form.carId)?.societyId,
                  )}{" "}
                  ·{" "}
                  {labelOf(
                    verifiedCars.find((car) => car._id === form.carId)?.flatId,
                  )}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="booking-service">Wash service *</Label>
              <Select
                value={form.serviceId}
                onValueChange={(serviceId) =>
                  setForm((current) => ({
                    ...current,
                    serviceId,
                    slotId: "",
                    bookingTime: "",
                  }))
                }
              >
                <SelectTrigger id="booking-service">
                  <SelectValue placeholder="Choose a wash service" />
                </SelectTrigger>
                <SelectContent>
                  {services.map((service) => (
                    <SelectItem key={service._id} value={service._id}>
                      {service.name} · ₹{service.price}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.serviceId && (
                <p className="text-xs text-slate-500">
                  {services.find((service) => service._id === form.serviceId)?.description}
                </p>
              )}
            </div>

            <div className="space-y-3">
              <div>
                <Label>Date and time slot *</Label>
                <p className="mt-1 text-xs text-slate-500">
                  Pick a day in the month calendar, then choose an available slot.
                </p>
              </div>
              <div className="grid gap-4 rounded-lg border border-slate-200 p-3 md:grid-cols-2">
                <Calendar
                  mode="single"
                  selected={
                    form.bookingDate
                      ? new Date(`${form.bookingDate}T12:00:00`)
                      : undefined
                  }
                  month={calendarMonth}
                  onMonthChange={(month) => {
                    setCalendarMonth(month);
                    if (
                      form.bookingDate &&
                      !form.bookingDate.startsWith(
                        `${month.getFullYear()}-${String(
                          month.getMonth() + 1,
                        ).padStart(2, "0")}`,
                      )
                    ) {
                      setForm((current) => ({
                        ...current,
                        bookingDate: "",
                        slotId: "",
                        bookingTime: "",
                      }));
                    }
                  }}
                  onSelect={(date) =>
                    setForm((current) => ({
                      ...current,
                      bookingDate: date ? toLocalDateInput(date) : "",
                      slotId: "",
                      bookingTime: "",
                    }))
                  }
                  disabled={{ before: new Date(`${today()}T00:00:00`) }}
                  fromDate={new Date(`${today()}T00:00:00`)}
                  showOutsideDays={false}
                  modifiers={{
                    hasAvailableSlots: (date) =>
                      availableSlotDates.has(toLocalDateInput(date)),
                  }}
                  modifiersClassNames={{
                    hasAvailableSlots:
                      "relative after:absolute after:bottom-1 after:right-1 after:h-1.5 after:w-1.5 after:rounded-full after:bg-emerald-500 after:content-['']",
                  }}
                  className="mx-auto"
                />
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-slate-800">
                    {form.bookingDate
                      ? new Date(`${form.bookingDate}T12:00:00`).toLocaleDateString(
                          undefined,
                          { weekday: "long", month: "long", day: "numeric" },
                        )
                      : "Select a date"}
                  </h3>
                  {!form.serviceId ? (
                    <p className="rounded-md bg-slate-50 p-3 text-sm text-slate-500">
                      Select a wash service to see days with open slots.
                    </p>
                  ) : slotsFetching ? (
                    <p className="p-3 text-sm text-slate-500">
                      Loading time slots…
                    </p>
                  ) : slotsError ? (
                    <div className="space-y-2 rounded-md border border-red-200 bg-red-50 p-3">
                      <p className="text-sm text-red-700">
                        Could not load slots for this date.
                      </p>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => refetchSlots()}
                      >
                        Retry
                      </Button>
                    </div>
                  ) : !form.bookingDate ? (
                    <p className="rounded-md bg-slate-50 p-3 text-sm text-slate-500">
                      Select a date in the calendar to view its time slots.
                    </p>
                  ) : selectedDateSlots.length === 0 ? (
                    <p className="rounded-md bg-slate-50 p-3 text-sm text-slate-500">
                      No slots have been scheduled for this date.
                    </p>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      {selectedDateSlots.map((slot: TAvailableSlot) => {
                        const available = slot.isBooked === "available";
                        const selected = slot._id === form.slotId;
                        return (
                          <button
                            key={slot._id}
                            type="button"
                            disabled={!available}
                            aria-pressed={selected}
                            onClick={() =>
                              setForm((current) => ({
                                ...current,
                                slotId: slot._id,
                                bookingTime: slot.startTime,
                              }))
                            }
                            className={[
                              "rounded-md border px-3 py-2 text-sm font-medium transition",
                              selected
                                ? "border-sky-600 bg-sky-600 text-white"
                                : available
                                  ? "border-slate-200 bg-white text-slate-700 hover:border-sky-400 hover:bg-sky-50"
                                  : "cursor-not-allowed border-slate-100 bg-slate-100 text-slate-400 line-through",
                            ].join(" ")}
                          >
                            {slot.startTime} – {slot.endTime}
                            {!available && (
                              <span className="mt-0.5 block text-xs no-underline">
                                {slot.isBooked === "booked" ? "Booked" : "Unavailable"}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                  {form.slotId && (
                    <p className="text-xs font-medium text-emerald-700">
                      Selected time: {form.bookingTime}
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="booking-remarks">Instructions (optional)</Label>
              <Textarea
                id="booking-remarks"
                maxLength={1000}
                placeholder="Anything the wash team should know?"
                value={form.remarks}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    remarks: event.target.value,
                  }))
                }
              />
            </div>

            {services.find((service) => service._id === form.serviceId) && (
              <div className="rounded-lg bg-slate-50 p-3 text-sm">
                <span className="text-slate-500">Amount due</span>
                <span className="float-right font-semibold text-slate-900">
                  ₹{services.find((service) => service._id === form.serviceId)?.price}
                </span>
              </div>
            )}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={closeForm}
                disabled={createState.isLoading}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={
                  createState.isLoading ||
                  verifiedCars.length === 0 ||
                  services.length === 0
                }
              >
                {createState.isLoading ? "Booking…" : "Confirm booking"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CustomerBookings;
